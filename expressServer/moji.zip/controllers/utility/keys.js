
const roles = {
    admin_key:"admin",
    editor_key:"editor",
    public_key:"public"
}

module.exports = {
    roles
};
